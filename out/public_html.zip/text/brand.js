module.exports = {
  ventleytech: {
    name: 'VENTLEY TECH',
    desc: 'VENTLEY TECH ',
    prefix: 'luxiren',
    footerText: 'Ventley Tech - All Rights Reserved 2025',
    logoText: 'Ventley Tech',
    projectName: 'VENTLEY TECH',
    url: 'luxireact.ux-maestro.com/ventleytech',
    img: '/images/ventleytech-logo.svg',
    notifMsg: ''
  }
};
