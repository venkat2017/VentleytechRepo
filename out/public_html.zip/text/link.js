const link = {
  ventleytech: {
    home: '/',
    contact: '/contact',
    upload:'/upload'
  }
};

export default link;
